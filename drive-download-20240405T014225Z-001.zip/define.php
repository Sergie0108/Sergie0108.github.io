<?php

define('ROOT_URL','https://jaraplasaninventorysystem.000webhostapp.com/KUYA_J_RESTAURANT/');
define('DB_HOST','localhost');
define('DB_USER','id21984212_root');
define('DB_PASS','Bd?-%|)F(d4TPD<Q');
define('DB_NAME','id21984212_login');

?>